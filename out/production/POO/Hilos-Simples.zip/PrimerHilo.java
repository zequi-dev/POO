public class PrimerHilo {
    /* ...*/
    public static void main (String args[]) throws InterruptedException{
        ThreadedPseudoIO pseudo = new ThreadedPseudoIO();
        try{
        pseudo.start();
        pseudo.sleep(1000);
        // Tarea principal continúa concurrentemente
        }catch(InterruptedException e){}
    }
    /* Otros métodos   */
}
class ThreadedPseudoIO extends Thread {
    /*.....*/
    public void run () {
        // Tarea segundaria concurrente
        System.out.println("Estoy corriendo");
    }
}
